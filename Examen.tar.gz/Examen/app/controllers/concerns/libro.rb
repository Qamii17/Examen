class Libro <ApplicationRecord
	validates :title, presence: true, uniqueness: true
	validates :autor, presence: true, length: {minimum: 10}
end

