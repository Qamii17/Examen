def index
	@libros =Libro.all
end

def show
	@libros =Libro.find(params[id:])
end

def new
	@libro = Libro.new(title: params[:article][:title], autor: params[:libro][:autor])
	@libro.save
	redirect_to @libro
end

def create
	@libro = Libro.new(title: params[:article][:title], autor: params[:libro][:autor])
	if @libro.save
		redirect_to @libro
	else
		render :new
	end
end

def destroy
	@libro = Libro.find(params[:id])
	@libro.destroy
	redirect_to libros_path
end

private
	def libro_params
		params.require(:titulo).permit(titulo, :body)
	end

	def edit
		<div style="width:30%;margin:0 auto;">
		<h1> Editar libro </h1>
		<%= render "form" %>
		</div>
	end