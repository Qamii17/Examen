class CreateLibros < ActiveRecord::Migration[5.2]
  def change
    create_table :libros do |t|
      t.string :title
      t.string :autor
      t.string :editorial
      t.integer :num_pag

      t.timestamps
    end
  end
end
